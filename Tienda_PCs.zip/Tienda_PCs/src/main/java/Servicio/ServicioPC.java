/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicio;

import com.mycompany.model.Pc;
import conexion.DatabaseConecction;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jamed
 */
public class ServicioPC {
    
    public static final String NOM_ARCHIVO = "data//Pc.txt";
    public static final int TAM_MARCA = 20;
    public static final int TAM_REGISTRO = 38; 
    
    
    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    
    
    public static boolean grabarPC(Pc comp) {
        try {
            conn = DatabaseConecction.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                //String insertDataSQL = "INSERT INTO EMPLEADO (CODIGO, NOMBRE) VALUES (" + dpto.getCodigo() + ",'" + dpto.getNombre() + "')";
                String insertDataSQL = "INSERT INTO EMPLEADO (ID, MARCA, PRECIO, ESTADO) VALUES(" + comp.getId()+ ", '" +  comp.getMarca()+ "', 'F', 12000)";
                int rowsAffected = stmt.executeUpdate(insertDataSQL);
                conn.close();
            } else {
                return false;
            }
            
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
            return false;
        }
        return true;
    }
    
    public static boolean actualizarPCOracle(Pc pc) {
    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "UPDATE PC SET MARCA = ?, PRECIO = ?, ESTADO = ? WHERE ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, pc.getMarca());
        ps.setDouble(2, pc.getPrecio());
        ps.setString(3, pc.getEstado());
        ps.setInt(4, pc.getId());

        ps.executeUpdate();

        ps.close();
        conn.close();

        return true;

    } catch (Exception e) {
        System.out.println("Error actualizar Oracle: " + e);
        return false;
    }
}
    
    public static Pc buscarPorIdOracle(int id) {
    Pc pc = null;

    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "SELECT * FROM PC WHERE ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            pc = new Pc(
                rs.getInt("ID"),
                rs.getString("MARCA"),
                rs.getDouble("PRECIO"),
                rs.getString("ESTADO")
            );
        }

        rs.close();
        ps.close();
        conn.close();

    } catch (Exception e) {
        System.out.println("Error buscar: " + e);
    }

    return pc;
}
    
    public static boolean guardarOracle(Pc pc) {
    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "INSERT INTO PC (ID, MARCA, PRECIO, ESTADO) VALUES (?, ?, ?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, pc.getId());
        ps.setString(2, pc.getMarca());
        ps.setDouble(3, pc.getPrecio());
        ps.setString(4, pc.getEstado());

        ps.executeUpdate();

        ps.close();
        conn.close();

        return true;

    } catch (Exception e) {
        System.out.println("Error al guardar en Oracle: " + e);
        return false;
    }
}
    
    public static List<Pc> listarPCsOracle() {
        int id;
        String marca;
        double precio;
        String estado;

        Pc comp = null;
        List<Pc> Pcs = new ArrayList<>();

        try {
            conn = DatabaseConecction.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
               String selectDataSQL = "SELECT ID, MARCA, PRECIO, ESTADO FROM PC WHERE ESTADO = 'A' ORDER BY ID";
                rs = stmt.executeQuery(selectDataSQL);
                
                while (rs.next()) {
                    id = rs.getInt("ID");
                    marca = rs.getString("MARCA");
                    precio = rs.getDouble("PRECIO");
                    estado = rs.getString("ESTADO");
                    comp = new Pc(id, marca, precio, estado);
                    Pcs.add(comp);
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return Pcs;
    }

    public static Pc buscarPorId(int pId) {
        try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r")) {
            file.seek(0);
            while (file.getFilePointer() < file.length()) {
                int id = file.readInt();
                String marca = file.readUTF().trim();
                double precio = file.readDouble();
                String estado = file.readUTF().trim();

                if (id == pId) {
                    return new Pc(id, marca, precio, estado);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar PC: " + ex.getMessage());
        }
        return null; 
    }

    public static boolean guardar(Pc pc) {
        if (buscarPorId(pc.getId()) != null) return false; 
        try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw")) {
            file.seek(file.length());
            file.writeInt(pc.getId());
            file.writeUTF(adjustStringLength(pc.getMarca(), TAM_MARCA));
            file.writeDouble(pc.getPrecio());
            file.writeUTF(adjustStringLength(pc.getEstado(), 2));
            file.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public static String adjustStringLength(String input, int n) {
        return (input == null) ? " ".repeat(n) : 
               (input.length() > n) ? input.substring(0, n) : 
               String.format("%-" + n + "s", input);
    }
    
   public static List<Pc> getListaPCs() {
    List<Pc> lista = new ArrayList<>();
    
    java.io.File archivo = new java.io.File(NOM_ARCHIVO);
    if (!archivo.exists()) return lista;

    try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r")) {
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            int id = file.readInt();
            String marca = file.readUTF().trim(); 
            double precio = file.readDouble();
            String estado = file.readUTF().trim();


            if (estado.equals("A")) {
                lista.add(new Pc(id, marca, precio, estado));
            }
        }
    } catch (Exception ex) {
        System.out.println("Error al listar: " + ex.getMessage());
        ex.printStackTrace();
    }
    return lista;
}
    
    public static boolean actualizarPC(Pc pNuevo) {
    try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw")) {
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            long posRegistro = file.getFilePointer();
            int id = file.readInt();
            
            if (id == pNuevo.getId()) {
                file.seek(posRegistro);
                file.writeInt(pNuevo.getId());
                file.writeUTF(adjustStringLength(pNuevo.getMarca(), TAM_MARCA));
                file.writeDouble(pNuevo.getPrecio());
                file.writeUTF(adjustStringLength(pNuevo.getEstado(), 2));
                file.close();
                return true;
            }

            file.readUTF();
            file.readDouble(); 
            file.readUTF(); 
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return false;
}
    
}        
