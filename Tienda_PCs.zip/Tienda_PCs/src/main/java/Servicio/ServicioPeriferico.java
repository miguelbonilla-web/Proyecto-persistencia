/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicio;

import com.mycompany.model.Pc;
import com.mycompany.model.Periferico;
import conexion.DatabaseConecction;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jamed
 */
public class ServicioPeriferico {

    public static final String NOM_ARCHIVO = "data//Periferico.txt";
    public static final int TAM_NOMBRE = 20;
    public static final int TAM_REGISTRO = 43;

    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    
    public static boolean eliminarOracle(int id) {
    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "UPDATE PERIFERICO SET ESTADO = 'I' WHERE ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);

        ps.executeUpdate();

        ps.close();
        conn.close();

        return true;

    } catch (Exception e) {
        System.out.println("Error eliminar periferico Oracle: " + e);
        return false;
    }
}
    
    public static boolean actualizarOracle(Periferico p) {
    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "UPDATE PERIFERICO SET ID_PC = ?, NOMBRE = ?, PRECIO = ?, ESTADO = ? WHERE ID = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, p.getIdPc());
        ps.setString(2, p.getNombre());
        ps.setDouble(3, p.getPrecio());
        ps.setString(4, p.getEstado());
        ps.setInt(5, p.getId());

        ps.executeUpdate();

        ps.close();
        conn.close();

        return true;

    } catch (Exception e) {
        System.out.println("Error actualizar periferico Oracle: " + e);
        return false;
    }
}
    
    public static Periferico buscarPorIdperifericoOracle(int id) {
    Periferico p = null;

    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "SELECT * FROM PERIFERICO WHERE ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            p = new Periferico(
                rs.getInt("ID"),
                rs.getInt("ID_PC"),
                rs.getString("NOMBRE"),
                rs.getDouble("PRECIO"),
                rs.getString("ESTADO")
            );
        }

        rs.close();
        ps.close();
        conn.close();

    } catch (Exception e) {
        System.out.println("Error buscar periferico Oracle: " + e);
    }

    return p;
}
    
    public static boolean guardarOracle(Periferico p) {
    try {
        Connection conn = DatabaseConecction.getConnection();

        String sql = "INSERT INTO PERIFERICO (ID, ID_PC, NOMBRE, PRECIO, ESTADO) VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, p.getId());
        ps.setInt(2, p.getIdPc());
        ps.setString(3, p.getNombre());
        ps.setDouble(4, p.getPrecio());
        ps.setString(5, p.getEstado());

        ps.executeUpdate();

        ps.close();
        conn.close();

        return true;

    } catch (Exception e) {
        System.out.println("Error guardar periferico Oracle: " + e);
        return false;
    }
}

    public static List<Periferico> listarPerifericosOracle() {

    int id;
    int id_pc;
    String nombre;
    double precio;
    String estado;

    Periferico perif = null;
    List<Periferico> perifericos = new ArrayList<>();

    try {
        conn = DatabaseConecction.getConnection();

        if (conn != null) {
            stmt = conn.createStatement();

            String selectDataSQL =
                "SELECT ID, ID_PC, NOMBRE, PRECIO, ESTADO " +
                "FROM PERIFERICO " +
                "WHERE ESTADO = 'A' " +
                "ORDER BY ID";

            rs = stmt.executeQuery(selectDataSQL);

            while (rs.next()) {
                id = rs.getInt("ID");
                id_pc = rs.getInt("ID_PC");
                nombre = rs.getString("NOMBRE");
                precio = rs.getDouble("PRECIO");
                estado = rs.getString("ESTADO");

                perif = new Periferico(id, id_pc, nombre, precio, estado);

                perifericos.add(perif);
            }

            conn.close();
        }

    } catch (Exception ex) {
        System.out.println("Error listar perifericos Oracle: " + ex);
    }

    return perifericos;
}
    public static boolean guardar(Periferico p) {
        Pc pcExistente = ServicioPC.buscarPorId(p.getIdPc());
        if (pcExistente == null) {
            return false;
        }

        if (buscarPorId(p.getId()) != null) return false;

        try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw")) {
            file.seek(file.length());
            file.writeInt(p.getId());
            file.writeInt(p.getIdPc()); // FK
            file.writeUTF(ServicioPC.adjustStringLength(p.getNombre(), TAM_NOMBRE));
            file.writeDouble(p.getPrecio());
            file.writeBoolean(p.isEsGamer());
            file.writeUTF(ServicioPC.adjustStringLength(p.getEstado(), 2));
            file.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public static Periferico buscarPorId(int pId) {
    try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r")) {
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            int id = file.readInt();
            int idPC = file.readInt();
            String nombre = file.readUTF().trim();
            double precio = file.readDouble();
            boolean esGamer = file.readBoolean();
            String estado = file.readUTF().trim();


            if (id == pId) {
                return new Periferico(id, idPC, nombre, precio, estado);
            }
        }
    } catch (Exception ex) {
        System.err.println("Error en buscarPorId: " + ex.getMessage());
    }
    return null;
}

    public static List<Periferico> getPerifericos() {
    List<Periferico> lista = new ArrayList<>();
    try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r")) {
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            int id = file.readInt();
            int idPC = file.readInt();
            String nombre = file.readUTF().trim();
            double precio = file.readDouble();
            boolean esGamer = file.readBoolean();
            String estado = file.readUTF().trim();

            if (estado.equals("A")) {
                lista.add(new Periferico(id, idPC, nombre, precio, estado));
            }
        }
    } catch (Exception ex) {
        System.out.println("Error al listar: " + ex.getMessage());
    }
    return lista;
}

    public static double calcularTotalPrecios() {
    double total = 0;
    List<Periferico> activos = getPerifericos();
    for (Periferico p : activos) {
        total += p.getPrecio();
    }
    return total;
}

    public static boolean actualizarPeriferico(Periferico pNuevo) {
    try (RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw")) {
        file.seek(0);
        while (file.getFilePointer() < file.length()) {
            long inicioRegistro = file.getFilePointer();
            int id = file.readInt();

            if (id == pNuevo.getId()) {
                file.seek(inicioRegistro);
                file.writeInt(pNuevo.getId());
                file.writeInt(pNuevo.getIdPc());
                file.writeUTF(ServicioPC.adjustStringLength(pNuevo.getNombre(), TAM_NOMBRE));
                file.writeDouble(pNuevo.getPrecio());
                file.writeBoolean(pNuevo.isEsGamer());
                file.writeUTF(ServicioPC.adjustStringLength(pNuevo.getEstado(), 2));
                file.close();
                return true;
            }

            file.readInt();
            file.readUTF();
            file.readDouble();
            file.readBoolean();
            file.readUTF();
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return false;
}

}

